# Regenerated catalog verification

100 written scores changed. All 200 audio files and 100 MIDI files have fresh hashes. Audio is finite, non-silent stereo at 32 kHz with the expected cue duration. MIDI note counts match native events. Bank routing has full coverage and no findings. Human listening remains pending. See verification.json for per-file hashes and measurements.
