# Neo-SPC v4 rebuild source pack

Contains the regenerated semantic catalog, full harness specification, professor-review passes, review rubric, generation/revision scripts and schemas used by the v4 benchmark.

Audio and MIDI are distributed in separate showcase downloads.
