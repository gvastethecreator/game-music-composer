#!/usr/bin/env python3
import json
from pathlib import Path
OUT=Path('/mnt/data/neospc_v4_work/data')

def rng(minv,maxv,default,step=.01,unit=None):
 d={'type':'range','min':minv,'max':maxv,'default':default,'step':step}
 if unit:d['unit']=unit
 return d

def enum(values,default):return {'type':'enum','values':values,'default':default}
def boolean(default):return {'type':'boolean','default':default}
def integer(a,b,d):return {'type':'integer','min':a,'max':b,'default':d}

h={
 'version':'3.0.0','name':'Neo-SPC Full Composition Harness','design_principle':'Hierarchical, deterministic composition with independent professor review and targeted revision.',
 'sections':{
  'brief':{
   'category':enum(['adventure','action','horror','towns','emotion','mystery','fantasy','electronic','urban','classical'],'adventure'),
   'game_context':enum(['exploration','combat','boss','stealth','chase','safe_room','town','dialogue','puzzle','reveal','travel','victory','defeat','cutscene'],'exploration'),
   'mood_primary':enum(['hopeful','heroic','mysterious','dread','melancholic','cozy','tense','sacred','playful','lonely','triumphant','uncanny','dreamlike'],'hopeful'),
   'mood_secondary':enum(['none','nostalgic','determined','ominous','tender','curious','ritualistic','mechanical','majestic','bittersweet'],'none'),
   'energy':rng(0,1,.55),'tension':rng(0,1,.35),'dominance':rng(-1,1,.1),'certainty':rng(0,1,.72),'complexity':rng(0,1,.55),
   'voice_budget':enum([8,12,16,20,24,28,32],16),'loop_bars':enum([8,12,16,20,24,32],16),'seed':integer(0,2147483647,2207)
  },
  'harmony':{
   'key':enum(list(range(12)),0),'scale_id':{'type':'enum','source':'scale-library.json','default':'ionian'},'progression_id':{'type':'enum','source':'chord-progression-library.json','default':'maj_pop_01'},
   'harmonic_rhythm_bars':rng(.25,4,1,.25),'extension_level':rng(0,1,.28),'modal_mixture':rng(0,1,.12),'secondary_dominants':rng(0,1,.08),'tritone_substitution':rng(0,1,0),'chromatic_mediants':rng(0,1,.05),'pedal_point':rng(0,1,.18),'inversion_rate':rng(0,1,.3),'voice_leading_weight':rng(0,1,.86),'cadence_strength':rng(0,1,.62),'modulation_rate':rng(0,1,0),'non_diatonic_budget':rng(0,.55,.08)
  },
  'form':{
   'architecture':enum(['period','sentence','binary','rounded_binary','ternary','rondo','through_composed','variation','fugue','process','layered_build','ambient_field'],'period'),
   'section_count':integer(2,8,4),'phrase_bars':enum([1,2,3,4,6,8],4),'phrase_asymmetry':rng(0,1,.12),'repetition':rng(0,1,.46),'variation':rng(0,1,.58),'section_contrast':rng(0,1,.62),'climax_position':rng(.35,.95,.76),'intro_bars':integer(0,8,2),'outro_bars':integer(0,8,0),'dropout_rate':rng(0,1,.16),'transition_density':rng(0,1,.38),'loop_tension':rng(0,1,.42),'return_pickup':rng(0,1,.45)
  },
  'melody':{
   'motif_preset':{'type':'enum','source':'pattern-preset-library.json#melody','default':'arch'},'contour':enum(['arch','ascending','descending','wave','terrace','narrow','angular','call_response'],'arch'),'tessitura':rng(0,1,.55),'range_semitones':integer(5,36,16),'density':rng(0,1,.46),'rest_ratio':rng(0,1,.22),'max_leap':integer(2,19,9),'stepwise_weight':rng(0,1,.66),'chord_tone_weight':rng(0,1,.74),'target_note_weight':rng(0,1,.82),'syncopation':rng(0,1,.3),'motif_recurrence':rng(0,1,.65),'motif_transformation':rng(0,1,.48),'sequence_rate':rng(0,1,.22),'ornament_rate':rng(0,1,.12),'pickup_probability':rng(0,1,.38),'call_response':rng(0,1,.35),'cadence_resolution':rng(0,1,.8)
  },
  'counterpoint':{
   'enabled':boolean(False),'voice_count':integer(1,6,2),'independence':rng(0,1,.58),'imitation':rng(0,1,.32),'entry_spacing_beats':rng(.25,16,4,.25),'contrary_motion':rng(0,1,.55),'oblique_motion':rng(0,1,.25),'parallel_motion_limit':rng(0,1,.18),'dissonance_budget':rng(0,1,.15),'prepared_dissonance':rng(0,1,.72),'voice_crossing_limit':rng(0,1,.08),'species_strictness':rng(0,1,.42),'stretto_probability':rng(0,1,.08)
  },
  'rhythm':{
   'meter':enum(['4/4','3/4','6/8','9/8','12/8','5/4','7/8','5/8','7/4'],'4/4'),'subdivision':enum(['quarter','eighth','sixteenth','triplet','mixed'],'eighth'),'swing':rng(0,.75,0),'groove_template':enum(['straight','backbeat','shuffle','bossa','samba','tango','one_drop','funk','breakbeat','motor','ritual','floating','waltz'],'straight'),'syncopation':rng(0,1,.32),'accent_displacement':rng(0,1,.12),'polyrhythm':rng(0,1,0),'additive_grouping':rng(0,1,.08),'metric_modulation':rng(0,1,0),'rhythmic_entropy':rng(0,1,.5),'fill_rate':rng(0,1,.18),'silence_weight':rng(0,1,.18)
  },
  'arp':{
   'enabled':boolean(True),'preset':{'type':'enum','source':'pattern-preset-library.json#arpeggio','default':'osc1'},'density':rng(0,1,.42),'octave_range':integer(1,4,2),'direction':enum(['up','down','up_down','down_up','random_walk','chordal'],'up_down'),'note_repeats':integer(0,6,0),'ratchet_rate':rng(0,1,.08),'skip_probability':rng(0,1,.12),'on_beat':rng(0,1,.55),'articulation':rng(0,1,.56),'chord_tone_priority':rng(0,1,.82),'pattern_bias':rng(0,1,.5),'morphing':rng(0,1,.2)
  },
  'bassline':{
   'preset':{'type':'enum','source':'pattern-preset-library.json#bassline','default':'root5'},'family':enum(['upright','finger','picked','analog','sub','bowed'],'upright'),'density':rng(0,1,.38),'range_octaves':rng(1,3,1.5,.25),'non_roots':rng(0,1,.2),'approach_notes':rng(0,1,.22),'transitions':rng(0,1,.3),'pedal_weight':rng(0,1,.22),'octave_jump_rate':rng(0,1,.08),'note_length':rng(0,1,.58),'on_beat':rng(0,1,.7),'pattern_bias':rng(0,1,.58),'morphing':rng(0,1,.18)
  },
  'drums':{
   'enabled':boolean(True),'kit':enum(['acoustic','brush','electronic','industrial','ritual','orchestral','toy','minimal'],'acoustic'),'density':rng(0,1,.48),'kick_weight':rng(0,1,.7),'snare_weight':rng(0,1,.65),'hat_weight':rng(0,1,.52),'tom_weight':rng(0,1,.18),'ghost_note_rate':rng(0,1,.2),'fill_rate':rng(0,1,.16),'open_hat_rate':rng(0,1,.08),'flam_rate':rng(0,1,.05),'velocity_spread':rng(0,1,.42),'timing_push_pull':rng(-1,1,0),'section_variation':rng(0,1,.55)
  },
  'orchestration':{
   'ensemble_profile':enum(['compact_band','folk_ensemble','rock_band','jazz_combo','chamber','orchestra','choir_orchestra','electronic_stack','hybrid'],'compact_band'),'primary_lead':enum(['flute','ocarina','reed','brass','strings','guitar','piano','vibes','synth_lead'],'flute'),'secondary_lead':enum(['none','flute','reed','brass','strings','guitar','vibes','synth_lead'],'none'),'layer_count':integer(1,12,4),'doubling_rate':rng(0,1,.18),'divisi_rate':rng(0,1,.08),'handoff_rate':rng(0,1,.32),'register_spread':rng(0,1,.62),'density_curve':enum(['flat','rising','arch','terraced','wave','sparse_to_full'],'arch'),'foreground_clarity':rng(0,1,.8),'ensemble_entry_threshold':rng(0,1,.58),'instrument_rotation':rng(0,1,.34),'timbre_contrast':rng(0,1,.62)
  },
  'texture':{
   'pad_density':rng(0,1,.2),'drone_density':rng(0,1,.08),'fx_density':rng(0,1,.06),'noise_texture':rng(0,1,.04),'granular_amount':rng(0,1,0),'stereo_width':rng(0,1,.55),'space_depth':rng(0,1,.48),'sample_grain':rng(0,1,.52),'texture_morph':rng(0,1,.18),'spectral_brightness':rng(0,1,.52),'low_mid_density':rng(0,1,.35)
  },
  'humanize':{
   'profile':{'type':'enum','source':'pattern-preset-library.json#humanize','default':'natural'},'timing_depth':rng(0,1,.24),'timing_correlation':rng(0,1,.78),'dynamics_depth':rng(0,1,.38),'velocity_curve':enum(['linear','soft','hard','s_curve'],'s_curve'),'articulation_variance':rng(0,1,.28),'duration_variance':rng(0,1,.2),'strum_time_ms':rng(0,100,14,1,'ms'),'strum_curve':rng(-1,1,.12),'breath_rate':rng(0,1,.16),'vibrato_depth':rng(0,1,.18),'vibrato_delay_ms':rng(0,500,160,10,'ms'),'phrasing_weight':rng(0,1,.72),'phrasing_offset':rng(-1,1,0),'role_placement':rng(0,1,.65)
  },
  'mix':{
   'master_volume_db':rng(-36,6,-3,.5,'dB'),'ceiling_dbfs':rng(-12,0,-1,.1,'dBFS'),'target_lufs':rng(-20,-12,-16,.1,'LUFS'),'lead_priority':rng(0,1,.76),'drum_presence':rng(0,1,.66),'bass_weight':rng(0,1,.6),'rhythm_weight':rng(0,1,.5),'harmony_weight':rng(0,1,.42),'atmosphere_weight':rng(0,1,.3),'kick_bass_duck_db':rng(0,4,1.2,.1,'dB'),'lead_duck_db':rng(0,4,1.8,.1,'dB'),'compression':rng(0,1,.35),'saturation':rng(0,1,.12),'eq_brightness':rng(-1,1,0),'stereo_width':rng(0,1,.58),'reverb_send':rng(0,1,.2),'delay_send':rng(0,1,.1)
  },
  'render':{
   'sample_rate':enum([32000,44100,48000],32000),'formats':enum(['ogg+mp3','wav+ogg+mp3','midi+ogg+mp3'],'midi+ogg+mp3'),'render_mode':enum(['mastered','live_mix','both'],'both'),'export_stems':boolean(False),'export_midi_cc':boolean(True),'loop_metadata':boolean(True),'normalize_mode':enum(['category_lufs','fixed_lufs','none'],'category_lufs')
  },
  'review':{
   'enabled':boolean(True),'minimum_score':rng(0,100,80,1),'max_revision_passes':integer(0,5,2),'independent_reviewer':boolean(True),'allow_harmony_repair':boolean(True),'allow_melody_reshape':boolean(True),'allow_rhythm_variation':boolean(True),'allow_orchestration_rebalance':boolean(True),'allow_expression_pass':boolean(True),'reject_if_rebuild':boolean(True)
  }
 },
 'workflow':['brief','harmony','form','melody','counterpoint','rhythm','arp','bassline','drums','orchestration','texture','humanize','mix','professor_review_1','targeted_revision','professor_review_2','render','final_qc'],
 'hard_rules':['Core reduction must work without pads or effects.','Review is independent from mix and renderer.','A note being in-scale is not sufficient evidence of good composition.','Every category uses idiomatic rhythm, bass and articulation contracts.','Pattern repetition must have formal function.','All automatic revisions are logged and reversible.']
}
OUT.mkdir(parents=True,exist_ok=True)
(OUT/'generation-harness-v3.json').write_text(json.dumps(h,indent=2))

rubric={
 'version':'3.0.0','name':'Independent Music Professor Review','scale':'0-10 per dimension; weighted score 0-100','dimensions':{
  'melodic_coherence':{'weight':1.3,'questions':['Does the line have destination tones?','Are leaps motivated and balanced?','Does the motif govern more than one phrase?']},
  'harmonic_logic':{'weight':1.4,'questions':['Do structural notes clarify the harmony?','Are non-chord tones prepared or resolved?','Does the bass support function and inversion?']},
  'phrase_and_form':{'weight':1.25,'questions':['Are phrases differentiated by function?','Is there breath, continuation and arrival?','Does the climax have preparation?']},
  'rhythm_and_groove':{'weight':1.1,'questions':['Is repetition purposeful?','Does the groove fit the declared style?','Do sections change rhythmic behavior?']},
  'counterpoint_voice_leading':{'weight':0.9,'questions':['Are independent voices genuinely independent?','Are collisions and parallels controlled?','Do inner voices create smooth motion?']},
  'orchestration':{'weight':1.0,'questions':['Is foreground/background hierarchy clear?','Do timbres fit role and register?','Do extra voices enter for formal reasons?']},
  'expression':{'weight':0.75,'questions':['Do timing, velocity and articulation express phrase structure?','Are repeated notes varied?','Are breaths and strums intentional?']},
  'idiomatic_character':{'weight':1.05,'questions':['Does the piece behave like its genre, not merely use genre instruments?','Are bass, drums and comping idiomatic?']},
  'loop_design':{'weight':0.65,'questions':['Does the end motivate the beginning?','Is the seam harmonically and rhythmically coherent?']},
  'identity':{'weight':0.9,'questions':['Is there a memorable thesis?','Could the cue be confused with another benchmark cue?']}
 },
 'thresholds':{'approved':80,'revise':67,'rebuild':0},'review_sequence':['listen to core reduction','inspect score','evaluate form and phrase','evaluate genre behavior','evaluate orchestration','evaluate performance','prescribe minimum targeted changes','review again']
}
(OUT/'professor-review-rubric.json').write_text(json.dumps(rubric,indent=2))
